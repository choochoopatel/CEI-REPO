import React from 'react'
import contact from './client'

const contact = () => {
    return (
        <section>
            
            
            .container 


        </section>
    )
}

export default contact