import React, { useState } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useLocation,
} from 'react-router-dom';
import './App.css';
import MyForm from './myForm';
import rcCarImg from './assets/rcCarImg.PNG';
import weatherImg from './assets/weatherImg.JPG';
import lightingImg from './assets/lightingImg.jpg';
import conveyorImg from './assets/conveyorImg.jpg';

function Home() {
  return (
    <div className="content-wrapper" id="home">
      <h2 id="line1">Welcome</h2>
      <h2 id="line3">To My Website</h2>
      <h5 id="line2">
        Hello and welcome to my website! This website will showcase a few projects that I have completed at Penn State. Feel free to provide any additional feedback to build upon my skills.
        Each project reflects the hands-on experience and technical knowledge I’ve gained throughout my academic journey. From engineering design to software development, my work highlights creativity, problem-solving, and a commitment to continuous improvement.

      </h5>
    </div>
  );
}

function About() {
  return (
    <div className="page">
      <div className="about-wrapper">
        <div className="about-image">
          <img src="/me.png" alt="Sunny Patel" />
        </div>
        <div>
          <div className="about-text">
            <h1>Sunny Patel</h1>
          </div>
          <div className="about-h">
            <h1>
              I am currently a student at Penn State studying Electrical and Computer Engineering Technology. My academic focus lies in embedded systems, circuit design, and programming for real-world applications. I have hands-on experience with microcontrollers, digital and analog electronics, and software development, and I enjoy applying what I learn through personal and team-based projects. My goal is to contribute to innovative technologies that bridge hardware and software, particularly in automation, robotics, or IoT. I'm always looking to grow as an engineer and connect with professionals who share a passion for solving complex problems.
            </h1>
          </div>
        </div>
      </div>

      <div className="experience">
        <h1>Experience</h1>
        <div className="circles">
          <div className="circle html">HTML</div>
          <div className="circle java">JAVA</div>
          <div className="circle python">PYTHON</div>
        </div>
      </div>
    </div>
  );
}

function Project() {
  const projects = [
    {
      image: rcCarImg,
      title: 'RC Car Project',
      description: 'A remote-controlled car with real-time steering and motor control.',
    },
    {
      image: weatherImg,
      title: 'IoT Weather Station',
      description: 'Built a system to monitor and transmit live weather data using sensors.',
    },
    {
      image: lightingImg,
      title: 'Smart Lighting System', 
      description: 'Automated lighting based on motion sensors and ambient light.',
    },
     {
      image: conveyorImg,
      title: 'Conveyor System',
      description: 'Mini conveyor belt system to simulate a real-world traffic light using data aquisition tools',
    },
  ];

  return (
    <div className="page">
      <h1>Project Gallery</h1>
      <div className="gallery">
        {projects.map((project, index) => (
          <div className="gallery-card" key={index}>
            <img
              src={project.image || '/placeholder.png'}
              alt={project.title}
              className="gallery-image"
              loading="lazy"
            />
            <div className="gallery-caption">
              <h3>{project.title}</h3>
              <p>{project.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Navbar() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const getTitle = () => {
    switch (location.pathname) {
      case '/':
        return 'Home';
      case '/about':
        return 'About Me';
      case '/contact':
        return 'Projects';
      case '/rate':
        return 'Feedback';
      default:
        return 'My Projects';
    }
  };

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <h2 className="navbar-title">{getTitle()}</h2>
      </div>

      <div className="navbar-center">
        <div className={`nav-links ${menuOpen ? 'show' : ''}`}>
          <Link to="/" onClick={handleLinkClick}>Home</Link>
          <Link to="/about" onClick={handleLinkClick}>About Me</Link>
          <Link to="/contact" onClick={handleLinkClick}>Gallery</Link>
          <Link to="/rate" onClick={handleLinkClick}>Provide Feedback</Link>
        </div>
      </div>

      <button
        className="hamburger"
        aria-label="Toggle menu"
        aria-expanded={menuOpen}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        &#9776;
      </button>

      <img src="/PSU.png" alt="Logo" className="logo" />
    </nav>
  );
}

function AppWrapper() {
  const location = useLocation();

  const getPageClass = () => {
    switch (location.pathname) {
      case '/':
        return 'home-background';
      case '/about':
        return 'about-background';
      case '/contact':
        return 'contact-background';
      case '/rate':
        return 'rate-background';
      default:
        return '';
    }
  };

  return (
    <div className={`app-wrapper ${getPageClass()}`}>
      <Navbar />
      <div className="content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Project />} />
          <Route path="/rate" element={<MyForm />} />
        </Routes>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppWrapper />
    </Router>
  );
}

export default App;